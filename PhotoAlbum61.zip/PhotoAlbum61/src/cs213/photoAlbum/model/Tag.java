package cs213.photoAlbum.model;

public class Tag {
	String tagType;
	
	String tagValue;
	
	public Tag(String tagType, String tagValue){
		this.tagType=tagType;
		this.tagValue=tagValue;
	}

}
